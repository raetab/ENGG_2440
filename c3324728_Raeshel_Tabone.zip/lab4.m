%% Lab4.m
% Alejandro Donaire 2020
% This script simulates the control system of a DC driven 1-link robotic manipulator.

% A few important rules:
    % - DO NOT MODIFY THIS SCRIPT OR THE SIMULINK MODEL.
    %   For this problem, You are being assessed on your ability to 
    %   write functions to setup simulations, write models in state-space form, 
    %   and desing a controller using pole placement as required.
    %
    % - You are being assessed on your ability to write code which
    %   is compatible with pre-existing models. If your code
    %   cannot generate the correct output (plots) with this model, then you
    %   need to analise the results and debug your code.
    %
    % - You must choose your variable names and values as required in the lab document. The script,
    %   function, Simulink models and automated marking software assume the variables are named as 
    %   in the lab document. You must use these variable names in your
    %   functions, script, etc).

%% Housekeeping 
%Close all windows, clear the workspace, clear the command line
close all;
clearvars;
clc;

global p

%% Setup the simulation
% Call a function which defines the model parameters and simulation setting and 
% returns these to the workspace. These parameters will then be available
% to simulink to use. This function takes no inputs.
[p,Z0,tfinal] = setupsim_lab4();

%% Compute the controller using pole placement
% Call a function that returns the numerator and denominator of the
% controller and save them in the variables numc and denc

[numc,denc]=controldesign_lab4(p);


%% Simulate the model rot_msd.slx
% Use the sim function to simulate the model "rob_manipulator_lab4.slx". Store the
% simulation outputs (the "to workspace" blocks) in a structure called
% "results".
results = sim('rob_manipulator_lab4.slx');

%% Plot the results
% Call a function to plot the simulation results. This function takes the 
% results structure from the sim function as an input and uses it to plot
% the results in a nice way. This function has no outputs (it just produces
% a plot).
plotresults_lab4(results,p);