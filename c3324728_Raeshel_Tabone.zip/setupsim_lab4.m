function [p,Z0,tfinal] = setupsim_lab4()
% Alejandro Donaire 2020
% This function should define parameters and matrices required to simulate the model
% of a robotic manipulator. The model parameters are already defined. You should complete the
% function by defining the matrices of the linerised model in the variables p.A, p.B, p.E, p.C, p.D, and 
% the initial contidion Z0 and the simulation final time tfinal. The structure 'p'
% allows us to use the parameters in other functions. For example in the
% function ss_model_lab4.m

% Model parameters given. Do not modify this part.

p.La=0.1;
p.Ra=1;
p.Km=0.4;
p.b=0.2;
p.Jm=0.1;
p.N=7;
p.m=5;
p.l=1;
p.g=9.8;
p.u=2;
p.T=20;

% Define the rest of the variables here
p.A = [-p.Ra/p.La -p.Km/p.Jm 0
       p.Km/p.La  -p.b/p.Jm  -p.l*p.m*p.g/p.N^2
       0      1/p.Jm    0]

p.B = [1;0;0]

p.E = [0;1/p.N;0]

p.C = [0 0 1/p.N]

p.D = [0]

Z0 =[0 0 (p.N*45*pi)/180]

tfinal = [14]

end