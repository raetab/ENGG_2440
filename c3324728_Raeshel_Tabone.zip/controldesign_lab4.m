function [numc,denc]=controldesign_lab4(p)
% Alejandro Donaire 2020
% This function should return the numerator and denominator of the
% controller transfer function. Follow the indication to write the code

% You need to design a controller with integral action such that the close
% loop characteristic polynomial has two poles in -2 and rest of the poles
% in -5.


% Use the command ss2tf to compute the numerator and denominator of the
% system tranfer function. Save the results in the variables num and den

[num,den]=ss2tf(p.A,p.B,p.C,p.D);

% Coefficients of the desired closed-loop characteristic polynomial (two
% poles in -2 and the rest in -5) and save de result in the variable ACL_coeff

ACL_coeff = poly([-5;-5;-5;-5;-2;-2])';

% Compute the matrix ME

ME = [1    0    0     0      0      0       0
      12   1    0     0      0      0       0   
      46   12   1     0      0      0       0
      100  46   12    5.714  0      0       0
      0    100  46    0      5.714  0       0
      0    0    100   0      0      5.714   0
      0    0    0     0      0      0       5.714];

% Compute the coefficients of the controller and save the result in the
% variable coeff
coeff = (ME\ACL_coeff)';

% Obtain the numerator and denominator of the controller and save the
% results in the variables numc and denc

numc = coeff(4:7);
denc = [coeff(1:3) 0];
