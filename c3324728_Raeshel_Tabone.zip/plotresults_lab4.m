function plotresults_lab4(results,p)
% Alejandro Donaire 2020
% This function should plot the results of the simple control system for a 1-link robotic manipulator.
% Read and understand the code, but you should not modify it.

figure(1)
clf

subplot(5,1,1)
plot(results.t,results.z(:,1)/p.La,'LineWidth',2)
xlabel('Time [s]','FontSize',16,'Interpreter','latex')
ylabel('$I_a$(t) [A]','FontSize',16,'Interpreter','latex')
title('Lab 4 - Simulation results','FontSize',16)
ylim([-8 4])
xlim([0 14])
grid on
grid minor

subplot(5,1,2)
plot(results.t,results.z(:,2)*180/pi/p.Jm/p.N,'LineWidth',2)
xlabel('Time [s]','FontSize',16,'Interpreter','latex')
ylabel('$\omega_p$(t) [deg/s]','FontSize',16,'Interpreter','latex')
ylim([-80 50])
xlim([0 14])
grid on
grid minor

subplot(5,1,3)
plot(results.t,results.z(:,3)*180/pi/p.N,'LineWidth',2)
xlabel('Time [s]','FontSize',16,'Interpreter','latex')
ylabel('$\theta_p$(t) [deg]','FontSize',16,'Interpreter','latex')
ylim([-20 50])
xlim([0 14])
grid on
grid minor

subplot(5,1,4)
plot(results.t,results.u,'LineWidth',2)
xlabel('Time [s]','FontSize',16,'Interpreter','latex')
ylabel('u(t) [v]','FontSize',16,'Interpreter','latex')
ylim([-8 2])
xlim([0 14])
grid on
grid minor

subplot(5,1,5)
plot(results.t,results.T,'LineWidth',2)
xlabel('Time [s]','FontSize',16,'Interpreter','latex')
ylabel('T(t) [N.m]','FontSize',16,'Interpreter','latex')
ylim([-10 30])
xlim([0 14])
grid on
grid minor

end