function [zdot] = ss_model_lab4(input)
% Alejandro Donaire 2020
% The strucure p contains all the parameters of the model

global p

%% The variables 'u', 'z', 'T' are extracted from the vector 'input'

u=input(1);
z=input(2:4);
T=input(5);
%% Write the state space equations here (zdot)

zdot = p.A*z + p.B*u + p.E*T;

% We do not use the output equation

